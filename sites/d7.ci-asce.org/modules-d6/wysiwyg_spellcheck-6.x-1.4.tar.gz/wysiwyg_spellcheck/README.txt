
wysiwyg_spellcheck.module is a wysiwyg editor plugin that enables TinyMCE spellcheck plugin.

Drupal module written by Ilya Ivanchenko.

