
tinyMCE.addToLang('break', {
  title: 'Anrisstext trennen',
  desc: 'Separiert den Anrisstext und Textkörper des Inhalts an dieser Stelle'
});

